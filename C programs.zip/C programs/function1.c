//functio.q
#include<stdio.h>
main()
void y();
void y();
{
	printf("y");
}
void main()
{
void a(),b(),c(),d();
y();
a();
b();
c();
d();
void a()
{
	printf("a");
	y();
}
void b()
{
	printf("b");
	a();
}
void c()
{
	a();
	b();
	printf("c");
}
void d()
{
	printf("d");
	c();
	b();
	a();
}
}
