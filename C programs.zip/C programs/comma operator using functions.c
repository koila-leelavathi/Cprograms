//Write a program for comma operator using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	int g,f;
	g=a+b,f=a-b;
	printf("g=%d,f=%d",g,f);
}
