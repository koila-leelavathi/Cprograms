#include<stdio.h>
main()
{
	char *str;
	char *first="online",*second="c",*third="program";
	sprintf(str,"%s%s%s",first,second,third);
}
