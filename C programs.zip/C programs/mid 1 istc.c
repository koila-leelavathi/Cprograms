//mid 1 ist c
#include<stdio.h>
main()
{
	int a=0,b=-1,c=1,d;
	d=(--a*(5+b)/2-c++*b);
	printf("%d",d);
}
