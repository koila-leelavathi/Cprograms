//write a program to print even noumber or odd noumber using functions
#include<stdio.h>
main()
{
	int n=10,eod(int);
	eod(n);
}
int eod(n)
{
	if (n%2==0)
	{
	 printf("given noumber is eeven no");	
	}
	else
	{
	  printf("given noumber is odd");
	}
}
