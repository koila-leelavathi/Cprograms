//Write a program for simple interest using functions
#include<stdio.h>
main()
{
	int p,t,r,si(int,int,int),d;
	printf("enter the value of p,t,r:");
	scanf("%d%d%d",&p,&t,&r);
	d=si(p,t,r);
}
int si(p,t,r)
{
	int mul,e;
	mul=(p*t*r);
	e=mul/100;
	printf("%d",e);
	return e;
}
