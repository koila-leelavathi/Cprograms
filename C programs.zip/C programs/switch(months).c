//Write a program to print all months using in switch case
#include<stdio.h>
main()
{
	char c;
	printf("choose your option to perform:\nA.January \nB.February \nC.March \nD.May \nE.Aprial \nF.June \nG.July \nH.August \nI.September \nJ.October \nK.November \nL.December");
	printf("\nchoose your option:");
	scanf("%c",&c);
	switch(c)
	{
	case 'A':
	printf("%c4weeks,4sundays");
	break;
	case 'B':
	printf("%c4weeks,4sundays");
	break;
	case 'C':
	printf("%c4weeks,4sundays");
	break;
	case 'D':
	printf("%c4weeks,5sundays");
	break;
	case 'E':
	printf("%c4weeks,4sundays");
	break;
	case 'F':
	printf("%c4weeks,4sundays");
	break;
	case 'G':
	printf("%c4weeks,5sundays");
	break;
	case 'H':
	printf("%c4weeks,4sundays");
	break;
	case 'I':
	printf("%c4weeks,5sundays");
	break;
	case 'J':
	printf("%c4weeks,4sundays");
	break;
	case 'K':
	printf("%c4weeks,4sundays");
	break;
	case 'L':
	printf("%c4weeks,5sundays");
	break;
	default:
	printf("enter wrong month");
   }
} 
