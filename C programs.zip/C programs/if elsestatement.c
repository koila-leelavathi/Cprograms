//write a program print the given noumber is even or not using if else statement
#include<stdio.h>
main()
{
	int a;
	printf("enter the value of a:");
	scanf("%d",&a);
	if(a%2==0)
	{
		printf("it is even noumber");
    }
    else
    {
	    printf("it is odd number");	
	}
}
