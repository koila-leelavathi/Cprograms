//write a program to print prfect number
#include<stdio.h>
main()
{
	int n,i,sum=0;
	printf("enter the valye of n:");
	scanf("%d",&n);
	for(i=1;i<n;i++)
	{
	 if(n%i==0)	
	 sum=sum+i;
	}
	if(sum==n)
	{
	  printf("it is perfect number");	
	}
	else
	{
	   printf("not a perfect noumber");	
	}
}
