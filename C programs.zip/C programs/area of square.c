//Write a program for area of square
#include<stdio.h>
main()
{
	int a,area;
	printf("enter the value of a:");
	scanf("%d",&a);
	area=a*a;
	printf("area=%d",area);
}
