#include <stdio.h>
void main()
{
	int a,b;
	printf("enter the values of a=");
	scanf("%d",&a);
	b=~a;
	printf("~a=%d",b);
}
