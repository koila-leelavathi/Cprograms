//Write a program to print area of cyilinder
#include<Stdio.h>
main()
{
	int area,r,h,pi,a;
	printf("enter the value of r,h:");
	scanf("%d%d",&h,&r);
	a=r*h;
	pi=3.14;
	area=2*pi*a;
	printf("area=%d",area);
}
