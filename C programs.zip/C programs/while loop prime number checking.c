/* Given number is prime number or not using while loop*/
#include <stdio.h>

int main()
{
 int k=2,m,c=0;
 printf("enter the no to be check whether it is prime or not=");
 scanf("%d",&m);
 while (k<=m)
 {
  if (m%k==0)
  {
   c=c+1;
  }
  k++;
 }
if (c==1)
 {
 printf("%d is a prime number",m);
 }
else
 {
 printf("%d is not a prime number",m);
 }
}

