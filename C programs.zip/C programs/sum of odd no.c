//Write a program to print sum of odd noumber
#include<stdio.h>
main()
{
	int a,i,sum=0;
	printf("enter the value of a:");
	scanf("%d",&a);
	for(i=0;i<=a;i++)
	 {
	   sum=sum+i;		
	  }
	  printf("%d",sum);	
}
