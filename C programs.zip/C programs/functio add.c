//functions
#include<stdio.h>
main()
{
	int x=1,y=2,z;
	z=add(x,y);
	printf("%d",z);
	{
	add(x,y)
    }	
	return(x+y);
}

