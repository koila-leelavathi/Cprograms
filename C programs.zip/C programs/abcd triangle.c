//Print ABCD in triangle
#include<Stdio.h>
main()
{
	char a,b;
	for(a=65;a<=69;a++)
	{
	 for(b=65;b<=a;b++)	
	{
	printf("%c",b);
    }
    printf("\n");
    }
}
