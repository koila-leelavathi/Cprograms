//to display something in new line
#include<stdio.h>
int main()
{
	printf("Hello");
	printf("\nwelcome");
	return 0;
}
