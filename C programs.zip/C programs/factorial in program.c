//program for factorial number 
#include<stdio.h>
int n=5;
main()
{   int fun(int);
    fun(n);
}
int fun(int n)
{
	int f,fact,k;
	f=1;
	fact=1;
	printf("enter the number to get factorial=");
	scanf("%d",&k);
	for (f;(f<=k);f++)
	{
	fact=fact*f;
        } 
        printf("The factorial of %d is=%d",k ,fact);

}
