#include<stdio.h>
main()
{
	int i,c(int,int);
	c(str1,str2);
}
int c(str1,str2)
{
	char str1[10]="leela",str2[10];
	for(i=0;str1[i]!='\0';i++)
	{
		str2[i]=str1[i];
	}
	printf("%s",str2);
}
