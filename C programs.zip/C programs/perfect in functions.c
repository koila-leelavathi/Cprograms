//write a program to print prfect number
#include<stdio.h>
main()
{
	int n,c(int);
	printf("enter the valye of n:");
	scanf("%d",&n);
	c(n);
}
int c(n)
{
	int i,sum=0;
	for(i=1;i<n;i++)
	{
	 if(n%i==0)	
	 sum=sum+i;
	}
	if(sum==n)
	{
	  printf("it is perfect number");	
	}
	else
	{
	   printf("not a perfect noumber");	
	}
}
