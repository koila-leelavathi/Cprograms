//Write a program to print area of sphere
#include<stdio.h>
main()
{
	int area,r,pi;
	printf("enter the value of r:");
	scanf("%d",&r);
	pi=3.14;
	area=4*pi*r*r;
	printf("area=%d",area);
}
