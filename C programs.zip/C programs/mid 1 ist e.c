//mid 1 ist e
#include<stdio.h>
main()
{
	int x=1,y=0,z=-1,d;
	d=!y||!z||!x||(z*y)&&(x+y);
	printf("%d",d);
	
}
