//conditional operator
#include<stdio.h>
main()
{
	int a,b,y,x,z;
	printf("enter the value of a,b:\n");
	scanf("%d%d",&a,&b);
	y=(a>b?0:1);
	printf("y=%d\n",y);
	x=(a<b?0:1);
	printf("x=%d\n",x);
	z=(a=b?0:1);
	printf("z=%d\n",z);
}
