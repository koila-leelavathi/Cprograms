#include<stdio.h>
main()
{
	int a=6;
	a=a<<1
	printf("%d\n",a);
}
