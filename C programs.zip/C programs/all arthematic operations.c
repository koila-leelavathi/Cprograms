//Write a program to print all arthematic operations using function
#include<stdio.h>
main()
{
	int add(int,int),sub(int,int),mul(int,int),divi(int,int),mod(int,int),a,b,c,d,e,f,g;
    printf("enter the value of a,b:");
    scanf("%d%d",&a,&b);
    c=add(a,b);
    printf("c=%d",c);
    d=sub(a,b);
    printf("d=%d",d);
    e=mul(a,b);
    printf("e=%d",e);
    f=divi(a,b);
    printf("f=%d",f);
    g=mod(a,b);
    printf("g=%d",g);
}
int add(a,b)
{
 return (a+b);
}
sub(a,b)
{
return (a-b);
}
mul(a,b)
{
return (a*b);
}
divi(a,b)
{
return (a/b);
}
mod(a,b)
{
return (a%b);
}
