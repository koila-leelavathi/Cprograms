#include <stdio.h>
#include <math.h>
void  main()
{
	long int a,b;
	a=pow(255,2567);
	b=pow(235,2567);
	printf("%ld",a*b);
}
