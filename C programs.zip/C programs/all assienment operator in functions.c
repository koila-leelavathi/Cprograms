//Write a program for all assienment operations using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	a+=b;
	printf("a1=%d",a);
	a-=b;
	printf("a2=%d",a);
	a*=b;
	printf("a3=%d",a);
	a/=b;
	printf("a4=%d",a);
	a%=b;
	printf("a5=%d",a);
}
