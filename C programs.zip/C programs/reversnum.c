//revers number
#include<stdio.h>
main()
{
	int n,sum=0,v;
	printf("enter the value of n:");
	scanf("%d",&n);
	while(n!=0)
	{
	 v=n%10;
	 sum=sum*10+v;
	 n=n/10;		
	}
    printf("%d",sum);
}
