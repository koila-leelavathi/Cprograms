#include<stdio.h>
int a=10;
main()
{
	static int a;
	printf("%d",a);
}
