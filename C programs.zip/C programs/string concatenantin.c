#include<stdio.h>
main()
{
	char str1[50],str2[50],i,j;
	printf("\nenter first string:");
	scanf("%s",str1);
	printf("\nenter second string :");
	scanf("%s",str2);
	for(i=0;str1[i]!='\0';i++)
	{
	}
    for(j=0;str2[j]!='\0';j++)
    {
	 str1[i+j]=str2[j];
    }
    str1[i+j]='\0';
    printf("\noutput:%s",str1);
    }

