#include <stdio.h>
main()
{
	int a,c(int);
	printf("enter the value of a=");
	scanf("%d",&a);
	c(a);
}
int c(int a)
{
	if (a%5==0)
	{
		printf("%d is divisible by 5");
	}
	else
	 if (a%3==0)
	 {
	 	printf("%d is divisible by 3");
	 }
	 else
	 if (a%7==0)
	 {
	 	printf("%d is divisible by 7");
	 }
	 else
	 printf("%d is not divisible by 5,3,7");
}
