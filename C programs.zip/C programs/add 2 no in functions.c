//Write a program to print add two num in functions
#include<stdio.h>
main()
{
	int add(int,int),a,b,z;
	printf("enter the a,b:");
	scanf("%d%d",&a,&b);
	z=add(a,b);
	printf("%d",z);
}
int add(a,b)
{    
return(a+b);	
}

