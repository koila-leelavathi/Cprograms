//Arthematic operations
#include<stdio.h>
main()
{
	int a,b,addition,subtraction,multiplication,modulardivision,division,unaryminus1,unaryminus2,c,d;
	printf("Arthematic Operations:");
	printf("Arthematic Operations;System performs arthematic operations,They are two type:");
	printf("1.Binary\n 2.Unary\n");
	printf("Binary:In binary we are using +,-,%,/,*\n");
	printf("Program for Binary operator:\n");
	printf("enter the value of a,b:\n" );
	scanf("%d%d\n",&a,&b);
	addition=a+b;
	subtraction=a-b;
	multiplication=a*b;
	modulardivision=a/b;
	division=a%b;
	printf("addition=%d",addition);
	printf("subtraction=%d",subtraction);
	printf("multiplication=%d",multiplication);
	printf("modulardivision=%d",modulardivision);
	printf("division=%d\n",division);
	printf("Unary:In binary we are using minus(-),address(&)\n");
	printf("Program for unary operator:");
	unaryminus1=-a;
	unaryminus2=-b;
	c=&a;
	d=&b;
	printf("unaryminus1=%d\n",unaryminus1);
	printf("unaryminus2=%d\n",unaryminus2);
    printf("addresss=%d\n",c);
    printf("addresss=%d\n",d);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
