//write a program to print message in negative noumber
#include<stdio.h>
main()
{
	int a;
	printf("enter the value of a:");
	scanf("%d",&a);
	if(a<0)
	{
	  printf("%d Is a negative noumber",a);
		}
	else
	{
		printf("%d Is not a negative noumber:",a);
	}
}
