//Write a program for size of the data type using functions
#include<stdio.h>
main()
{
	int c(int),a;
	char d(char),b;
	float f(float),e;
	printf("enter the value a,b,e:");
	scanf("%d%d%d",&a,&b,&e);
	c(a);
	d(b);
	f(e);
}
int c(a)
{
	int g;
	g=sizeof(a);
	printf("%d",g);
}
char d(b)
{
	char h;
	h=sizeof(b);
	printf("%d",h);
}
float f(e)
{
	float i;
	i=sizeof(e);
	printf("%d",i);
}
