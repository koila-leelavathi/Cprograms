#include<stdio.h>
main()
{
	int i,n,a[10],t,r;
	printf("enter the size of the binary code:");
	scanf("%d",&n);
	printf("'enter the binary code:");
	for(i=0;i<n;i++)
	{
	 scanf("%d",&a[i]);	
	}
	printf("%d",a[0]);
	for(i=0;i<n-1;i++)
	{
		if(a[i]+a[i+1]==2)
		{
		 printf("0");	
		}
		else
		{
		 t=a[i]+a[i+1];
		 printf("%d",t);	
		}
	}
}
