//to display addition of two numbers
#include<stdio.h>
int main()
{ 
	int a,b,c;
	a=1;
	b=2;
	c=a+b;
	printf("sum=%d",c);
	return 0;
}
