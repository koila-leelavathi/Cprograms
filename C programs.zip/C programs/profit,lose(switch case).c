//Write a program to print profit and lose
#include<stdio.h>
main()
{
	int costprise,sellingprise,profit,lose,c;
	printf("enter the value of cost prise:");
	scanf("%d",&costprise);
	printf("enter the value of selling prise:");
	scanf("%d",&sellingprise);
	printf("choose option to perform:\n 1.profit,lose");
	printf("\nchoose your option");
	scanf("%d",&c);
	switch(c)
	{
	case 1:
	profit=sellingprise-costprise;
	printf("\nprofit=%d",profit);
	lose=costprise-sellingprise;
	printf("\nlose=%d",lose);
	break;
	case 2:
	break;
	default:
	printf("\nThere is no lose and profit");
	break;
	}
}
