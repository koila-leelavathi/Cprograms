//Write a program to print all relational operations using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	int d,e,f,g;
	d=a<b;
	printf("d=%d",d);
	e=a>b;
	printf("e=%d",e);
	f=a<=b;
	printf("f=%d",f);
	g=a>=b;
	printf("g=%d",g);
}
