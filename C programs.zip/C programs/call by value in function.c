//call by value:based on actual arguments and formal argumrnts recieved the value
#include<stdio.h>
main()
{
  int swap(int,int),x=10,y=20;
  swap(x,y);
  printf("%d%d",x,y);	
}
int swap(int a,int b)
{
	int temp;
	temp=a;
	a=b;
	b=temp;
	printf("%d%d",a,b);
}
