//Write a program to print factorial noumbers in do while
#include<stdio.h>
main()
{
	int fact,i,k;
	printf("enter the number:");
	scanf("%d",&k);
	do
	{
	 i=1;
	 fact=1;
	 printf("%d",fact*i);
	 i++;
	 }
	 while(i<=k);
}
