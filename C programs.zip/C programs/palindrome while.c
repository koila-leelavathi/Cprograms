#include <stdio.h>
void main()
{
	int n,i,s,sum=0;
	printf("enter the number to check whether it is a palindrome or not:-");
	scanf("%d",&n);
	i=0;
	while (n!=0)
	{
	s=n%10;
    n=n/10;
	sum=sum*10+s;
	i++;
    }
   	printf("%d",sum);
}
