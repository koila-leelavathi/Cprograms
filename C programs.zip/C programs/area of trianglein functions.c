//Write a program to print aarea of triangle using functions
#include<Stdio.h>
main()
{
	int a,b,area(int,int),c;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c=area(a,b);
}
int area(a,b)
{
	int area,d;
	d=a*b;
	area=d*0.5;
	printf("%d",area);
	return area;
}
