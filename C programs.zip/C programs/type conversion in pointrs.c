#include<stdio.h>
main()
{
	void *p;
	int x=10;
	char A;
	float f;
	p=&x;
	printf("%d",*((int *)p));
}













