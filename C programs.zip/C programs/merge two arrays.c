#include <stdio.h>
void main()
{
	int a,i,k[100],s,se[100],merge[10000],m,in=0;
	printf("enter the size of 1ST array=");
	scanf("%d",&a);
	printf("enter the size of the 2nd array=");
	scanf("%d",&s);
	printf("enter the elements in 1st array=");
	for (i=0;i<a;i++)
	{
	   scanf("%d",&k[i]);
	}
	printf("enter the elements in 2nd array=");
	for (i=0;i<s;i++)
	{
		scanf("%d",&se[i]);
	}
	m=a+s;
	for (i=0;i<a;i++)
	{
		merge[in]=k[i];
		in++;
	}
    for (i=0;i<s;i++)
    {
    	merge[in]=se[i];
    	in++;
	}
	for (i=0;i<m;i++)
	{
		printf("%d",merge[i]);
	}
	
}

