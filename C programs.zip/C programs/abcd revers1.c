//Reverse triangle
#include<stdio.h>
main()
{
	char i,j;
	for(i='D';i>='A';i--)
	{
	 for(j=i;j>='A';j--)
	 {
	   printf("%c",j);		
	 }
	 printf("\n");	
	}
}
