//Write a program to pritf weeks and sundays in moths
#include<stdio.h>
main()
{
	int a;
	char A;
	printf("choose your 1st option to perform:\n1.Januaury \n2.Februaaury \n3.March \n4.Aprial \n5.May \n6.June \n7.July \n8.August \n9.September \n10.October \n11.November \n12.December");
    printf("choose your 2nd option to perform:\n1A.4weeks,4sundays \n2B.4weeks,4sundays \n3C.4weeks,4sundays \n4D.4weeks,5sundays \n5E.4weeks,4sundays \n6F.4weeks,5sundays \n7G.4weeks,4sundays \n8H.4weeks,5sundays \n9I.4weeks,5sundays \n10J.4weeks,4sundays \n11K.4weeks,4sundays \n12L.4weeks,5sundays");
    printf("choose your 1st option:");
	scanf("%d",&a);
	printf("choose your second option:");
	scanf("%c",&A);
	switch(A)
	{
	case A:
	printf("1.JAnuary");
	printf("1A..4weeks,4sundays");
	break;
	case B:
	printf("\n2.Februaaury");
	printf("\n2B.4weeks,4sundays");
	break;
	case C:
	printf("\n3.March");
	printf("\n3C.4weeks,4sundays");
	break;
	case D:
	printf("\n4.Aprial");
	printf("\n4D.4weeks,5sundays");
	break;
	default:
		printf("wrong months and days");
    }
}
