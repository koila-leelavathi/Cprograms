//Write a program for size of uisng pointers
#include<stdio.h>
main()
{
	int a,*d;
	float b;
	char c;
	d=(&a);
	printf("%d size of a:",sizeof(a));
	
}
