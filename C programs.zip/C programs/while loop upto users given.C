#include <stdio.h>
int main()
{
 int k,n;
 k=1;
 printf("enter the range=");
 scanf("%d",&n);
 while (k<=n)
 {
 printf("%d",k);
 k++;
 }
}
