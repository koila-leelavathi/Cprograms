//Write a program to print triangle stars
#include<stdio.h>
main()
{
	int n,m,c,r;
	printf("enter the rows");
	scanf("%d",&n);
	for(c=1;c<=n;c++)
	{
	   for(r=1;r<=n-c;r++){
			printf(" ");
		}
		for(m=0;m!=2*c-1;m++){
			printf("*");
	
		}
		printf("\n");
		
	}
}

