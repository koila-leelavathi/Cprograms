//write a program to print all operations using switch case
#include<stdio.h>
main()
{
	int a,b,c,d,e,f,g,h;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	printf("coose your option:\n 1.Addition \n 2.subtraction \n 3.multiplicaion \n 4.divisioin \n 5.modular division");
	printf("\n choose your option");
	scanf("%d",&c);
	switch(c)
	{
	case 1:
	c=a+b;
	printf("%d",c);
	break;
	case 2:
	d=a-b;
	printf("%d",d);
	break;
	case 3:
	e=a*b;
	printf("%d",e);
	break;
	case 4:
	f=a%b;
	printf("%d",f);
	break;
	case 5:
	g=a/b;
	printf("%d",g);
	break;
	default:
	printf("choose right option");
	break;
    }
}

