//equivalen condition
#include<stdio.h>
main()
{
	int a,b,c;
	printf("ente the value of a,b:");
	scanf("%d%d",&a,&b);
	c=(a==b);
	printf("%d",c);
}
