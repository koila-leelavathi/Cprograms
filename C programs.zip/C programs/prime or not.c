/* CHECKING PRIME NUMBER OR NOT */
#include<stdio.h>
int main()
{
	int m,b=2,c=0;
	printf("Enter a number:");
	scanf("%d",&m);
	for(b;b<=m;b++)
	{
		if(m%b==0)
		{
			c=c+1;
		}
}
	if(c==1)
	{
		printf("given number is a prime number");
	}
	else{
		printf("given number is not prime number");
	}
}

