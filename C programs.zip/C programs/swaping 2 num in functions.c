//Writw a program for swaping two numbers using temparay variable using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	int temp;
	temp=a;
	a=b;
	b=temp;
	printf("%d%d",a,b);
}
