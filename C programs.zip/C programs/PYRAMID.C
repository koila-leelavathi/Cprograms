#include<stdio.h>
int main()
{
int i,j,k,r;
printf("enter number of rows");
scanf("%d",&r);
for(i=r;i>=1;i--)
{
for(j=1;j<=i;j++)
{
printf(" ");
}
for(k=i;k<=r;k++)
{
printf("%c ",j);
}
printf("\n");
}
return 0;
}
