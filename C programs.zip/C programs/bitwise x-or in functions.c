//Write a program for bitwise x-or using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	int d;
	d=(a^b);
	printf("%d",d);
}
