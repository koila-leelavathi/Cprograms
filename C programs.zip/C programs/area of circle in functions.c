//Write a program for area of circle
#include<stdio.h>
main()
{
	int pi,r,area(int);
	printf("enter the value of r:");
	scanf("%d",&r);
	area(r);
}
int area(r)
{
	int area,c,pi;
	pi=3.14;
	c=r*r;
	area=pi*c;
	printf("%d",area);
	
}
