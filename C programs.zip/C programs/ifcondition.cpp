//if condition
#inlude<stdio.h>
main()
{
	int a,b;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	if(a<b)
	printf("%d",a<b);
}
