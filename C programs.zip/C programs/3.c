#include<stdio.h>
void display()
{
	extern int c;
	printf("%d",c);
	c=40;
	printf("%d",c);
}
