//Write a program to print function
#include<stdio.h>
main()
{
	int l();
	l();
}
int l()
{
	int u=10;
	u++;
	printf("%d",u);
}
