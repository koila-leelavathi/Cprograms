#include<stdio.h>
main()
{
	int x=5,y;
	printf("%d\n",x);
	printf("%d\n",&x);
	y=&x;
	printf("%d\n",y);
	printf("%d\n",&y);
}
