//Write a program o printf function without arguments with return value
#include<stdio.h>
main()
{
	int add(),z;
	z=add();
	printf("calling function z=%d",z);
}
int add()
{
	int add,x=10,y=11;
	add=x+y;
	printf("add=%d",add);
	return(add);
}

