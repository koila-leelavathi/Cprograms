//Write an given noumber is greater,less or eqal noumber
#include<stdio.h>
main()
{
	int a,b,c;
	printf("enter the value of a,b,c:");
	scanf("%d%d%d",&a,&b,&c);
	 if(a>0)
	 {
	   printf("The given noumber is greater noumber",a);
	 }
	 if(b>0)
	 {
	    printf("The given noumber is less noumber",b);
	 }
	 if(c==0)
	 {
	   printf("The given noumber is equal noumber",c);
	 }
}
