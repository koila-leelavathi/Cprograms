#include<stdio.h>
main()
{
   int n,c(int);
   printf("Even numbers upto\n");
   scanf("%d",&n);
   c(n);
}
int c(n)
{
   do
   {
      if( n%2 == 0)
	  printf("%d",n);
      n++;
   }
   while( n <= 10 );
}

