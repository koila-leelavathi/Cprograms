#include <stdio.h> 
  
main () 
{   int i;
 
   for(i=0; ; ) 
   { 
      printf("This loop will run forever.\n"); 
   } 
 
   return 0; 
} 
