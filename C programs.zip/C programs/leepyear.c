//leep year
#include<stdio.h>
main()
{
	int year;
	printf("enter the value of year:");
	scanf("%d",&year);
	if((year%4==0)&&(year%100!=0)||(year%400==0))
	
			{
			    printf("%d is the year is leep year:",year);	
				}
			else
			{
				printf("%d not a leep year",year);
				}
	
}
