#include<Stdio.h>
void main()
{
  int a=10;
  printf("%d\n",~a);	
}
