//to display one integer in variable value
#include<stdio.h>
int main()
{
	int a=10;
	printf("value=%d",a);
	return 0;
}
