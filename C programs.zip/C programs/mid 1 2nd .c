#include<stdio.h>
main()
{
	int i,n,a=4;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	a=a*2;
}
