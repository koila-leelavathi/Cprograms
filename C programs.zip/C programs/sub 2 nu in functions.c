//Write a program to print subtraction of two numbers using functions
#include<stdio.h>
main()
{
	int a,b,z,subtraction(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	z=subtraction(a,b);
	printf("%d",z);
}
int subtraction(a,b)
{
	int c;
	c=(a-b);
    return c;
}
