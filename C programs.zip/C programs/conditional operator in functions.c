//Write a program for conditional operator using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the values of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	int d;
	d=(a<b?0:1);
	printf("%d",d);
}
