//write a program to print sum of even numbers
#include<stdio.h>
main()
{
	int a,i,sum=0;
	printf("enter the value of a:");
	scanf("%d",&a);
	for(i=0;i<=a;i++)
	{
	if(i%2==0)
	{
		sum=sum+i;
	} 
	}
	 printf("%d",sum);
}
