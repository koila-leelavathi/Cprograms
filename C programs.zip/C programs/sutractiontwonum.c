//sbutract two numbers
#include <stdio.h>
main()
{
	int a,b,c;
	printf("subtract two numbers");
	printf("enter the values of a,b:%d");
	scanf("%d%d",&a,&b);
	c=a-b;
	printf("c=%d",c);
	
}
