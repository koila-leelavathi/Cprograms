//Write a progran to print sum of two arrays
#include<stdio.h>
main()
{
	int a[10][10],b[10][10],n,m,i,j,sum;
	printf("enter the value of n,m:");
	scanf("%d%d",&n,&m);
	printf("enter the first array:");
	for(i=0;i<n;i++)
	{
	 for(j=0;j<m;j++)
	 {
	  scanf("%d%d",a[i][j]);
	 }
	}
	printf("enter the econd array:");
	for(i=0;i<n;i++)
	{
	 for(j=0;j<m;j++)
	 {
	  printf("%d%d",b[i][j]);		
	 }	
	}
	printf("sum of the array");
	for(i=0;i<n;i++)
	{
	 for(j=0;j<m;j++)
	 {
	  printf("d",a[i][j]+b[i][j]);
	 }	
	}
	printf("\n");
}
