//mid 1 ist lo B
#include<stdio.h>
main()
{
	int a,b;
	float c;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c=a+b;
	printf("%f",c);
	return 0;
}
