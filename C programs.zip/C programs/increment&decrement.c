#include<stdio.h>
main()
{
   int a,b,c,d,e;
   printf("enter the value of a");
   scanf("%d",&a);
   b=--a;
   c=a--;
   d=++a;
   e=a++;
   printf("b=%d",b);
   printf("c=%d",c);
   printf("d=%d",d);
   printf("e=%d",e);
}
