//to display the value in space
#include<stdio.h>
int main()
{ 
	printf("Hello \t How are you");
	return 0;
}
