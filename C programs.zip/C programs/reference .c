//call by reference:Holding the address 
//pointer :Holding address of tthe variable
#include<stdio.h>
main()
{
  int swap(int*,int*),*x=10,*y=20;
  swap(*x,*y);
  printf("%d%d",*x,*y);	
}
int swap(int *a,int *b)
{
	int *temp;
	*temp=*a;
	*a=*b;
	*b=*temp;
	printf("%d%d",*a,*b);
}
