//Post increment
#include<stdio.h>
main()
{
	int a,c;
	printf("enter the valie of a:");
	scanf("%d",&a);
	c=a++;
	printf("%d",c);
}
