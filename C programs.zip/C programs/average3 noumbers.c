//Write a program to print avarage of three noumbers
#include<stdio.h>
main()
{
	int a,b,c,avg,sum;
	printf("enter the value of a,b,c:");
	scanf("%d%d%d",&a,&b,&c);
	sum=a+b+c;
	avg=sum/3;
	printf("The avg is=%d",avg);
	
}
