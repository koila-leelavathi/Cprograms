//Write a program to print in 100 numbers to print the even noumber
#include<stdio.h>
main()
{
	int a,i;
	printf("enter the value of a:");
	scanf("%d",&a);
	for(i=0;i<a;i++)
	{
	if(i%2==0)
	  {
	     printf("%d is the enen number:\n",i);		
	  }
    
    
	
	}
}
