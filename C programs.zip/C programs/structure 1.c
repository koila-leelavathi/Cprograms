#include<stdio.h>
main()
{
	struct
	{
	 char book[30];
	 int pages;
	 float price;	
    }b1;
    printf("%d\n",sizeof(b1.book));
    printf("%d\n",sizeof(b1.pages));
    printf("%d\n",sizeof(b1.price));
}
