#include<stdio.h>
main()
{
	int a,b,d;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	d=(a|b);
	printf("d=%d",d);
}
