#include <stdio.h>
int main()
{
	/*int i,j,k=0;
	j=2*3/4+2.0/5+8/5;
	k-=--j;
	for (i=0;i<5;i++)
	{
		switch (i+k)
		{
			case 1:
			case 2:
				printf("%d",i+k);
			case 3:
				printf("%d",i+k);
			default:
				printf("%d",i+k);
		}
	}
    int m=10;
	int x=printf("%d ",m);
	printf("%d",x);

	char x='Ab';	
	printf("%c",x);	
	return 0;
	
	int a=1,b=2,c=3;
	printf("%d %d %d");*/
	int n=0;
	while(n<printf("menu\n"))
	{
		n++;
	}
	return 0;

	
}
