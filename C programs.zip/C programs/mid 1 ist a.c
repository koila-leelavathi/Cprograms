//mid 1 1st question
#include<stdio.h>
main()
{
	int x=4,y=5,z=6,c;
	c=(++x*(y-3)/2-z++*y);
	printf("%d",c);
}
