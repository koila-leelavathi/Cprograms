//to display area of rectangle
#include<stdio.h>
int main()
{
	int length,width,area;
	length=15;
	width=30;
	area=length*width;
	printf("area=%d",area);
	return 0;
}
