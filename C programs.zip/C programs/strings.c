#include <stdio.h>
void main()
{
	char a[1000],character;
	int i,c=0;
	printf("enter a string=");
	gets(a);
	printf("enter the character which you want frequency=");
	scanf("%c",&character);
	for (i=0;a[i]!='\o';i++);
	{
	   if (character==a[i])
	   c++;
	}
	printf("%c character frequency is=%d",character,c);
}
