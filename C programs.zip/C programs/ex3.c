#include<stdio.h>
main()
{
	int x=5,y;
	printf("%d\n",x);
}
