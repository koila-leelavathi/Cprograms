//write a program to print grade and remarks using switch case
#include<stdio.h>
main()
{
	int c;
	printf("choose the option to perform:\n1.Excelent \n2.Good \n3.Average \n4.Below Average \n6.Fail \n5.Pass");
	printf("\nchoose your option:");
	scanf("%d",&c);
	switch(c)
	{
    case 1:
	printf("100marks");
	break;
	case 2:
	printf("95marks");
	break;
	case 3:
	printf("75marks");
	break;
	case 4:
	printf("50marks");
	break;
	case 5:
	printf("35marks");
	case 6:
	printf("20marks");
	break;
	default:
	printf("Wrong option");
    }
}
