#include<stdio.h>
main()
{
	int a,b,f;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	f=(a^b);
	printf("f=%d",f);
}
