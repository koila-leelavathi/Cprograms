#include<stdio.h>
main()
{
	int k=0;
	for(;;k++)
	{
	 printf("Hello");
	 if(k%10==0)
	 break;	
	}
	return 0;
}
