// 1,1,2,3,5,8,.................
#include<stdio.h>
int main()
{
	int num1=0,num2=1,ra,nu;
	printf("How many numbers of fibnocci series u want>>");
	scanf("%d",&ra);
	printf("%d",1);
	for(ra;ra>1;ra--)
	{
		
		nu=num1+num2;
		printf(",%d",nu);
		num1=num2;
		num2=nu;	
	}
}

