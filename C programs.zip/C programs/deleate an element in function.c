/* DELETING THE DUPLICATE ELEMENTS BY K.LEELAVATHI S160161*/
#include<stdio.h>
int main()
{
	int n,c(int);
	printf("enter the size of the array>>");
	scanf("%d",&n);
	c(n);
}
int c(n)
{
	int i,j,de,n1,c=0;
	n1=n;
	int a[n],b[n];
	for(i=0;i<n;i++)
	{
		printf("enter the %d element>>",i);
		scanf("%d",&a[i]);
		b[i]=a[i];
	}
	printf("enter the element that have to be deleted>>");
	scanf("%d",&de);
	for(i=0;i<n;i++)
	{
		if(b[i]==de)
		{
			
			for(j=i-c;j<n1-1;j++)
			{
				a[j]=a[j+1];
				
			}
			n1=n1-1;
			c=c+1;
		}
	}
	for(i=0;i<n1;i++)
	{
		printf("%3d",a[i]);
	}
}
