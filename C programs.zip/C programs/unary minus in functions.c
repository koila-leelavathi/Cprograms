//Write a program for unary minus using functions
#include<stdio.h>
main()
{
	int a,c(int);
	printf("enter the vale of a:");
	scanf("%d",&a);
	c(a);
}
int c(a)
{
	int unary;
	unary=-a;
	printf("unary=%d",unary);
}
