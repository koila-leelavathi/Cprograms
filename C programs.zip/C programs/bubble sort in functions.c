#include<stdio.h>
main()
{
int n,c(int);
printf("enter noumber of elements:");
scanf("%d",&n);
c(n);
}
int c(int n)
{
int i,j,a[10],temp;
printf("enter elements:");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=n;i>0;i--)
{
for(j=0;j<(i-1);j++)
{
if(a[j]>a[j+1])
{
temp=a[j];
a[j]=a[j+1];
a[j+1]=temp;
}
}
}
  printf("sorted array is:");
   for(i=0;i<n;i++)
    {
    printf("%3d",a[i]);
    }
  }
