//Float values 2
#include<stdio.h>
main()
{
	int z,x,y;
	printf("enter the value of x,y:");
	scanf("%d",&x,&y);
	z=x/y;
	printf("%d",z);
	printf("%f",float(z));
	
	
}
