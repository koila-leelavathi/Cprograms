//Mid 1 b answers
#include<stdio.h>
main()
{
	int a=1,b=0,c=-1,d;
	d=(a+=b-c=*10);
	printf("%d",d);
	
}
