#include<stdio.h>
main()
{
	int n,fact;
	int factorial(int);
	printf("enter n:");
	scanf("%d",&n);
	fact=factorial(n);
	printf("%d",fact);
}
int factorial(int n)
{
	int result;
	if(n==0)
	{
	  result=1;	
	}
	else
	{
	 result=n*factorial(n-1);	
	}
	return result;
}
