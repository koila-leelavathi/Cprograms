//FLOAT Values in interes
#include<stdio.h>
main()
{
	 int x=8.5;
	 printf("%d",x);
}
