//Assinging pointer to another variavble
#include<stdio.h>
main()
{
	int a=5,*ptr,b;
	ptr=&a;
	printf("a=%d\n",a);
	printf("&a=%d\n",&a);
	printf("ptr=%d\n",ptr);
	printf("*ptr%d\n",*ptr);
	b=*ptr;
	printf("b=%d\n",b);
	printf("&b=%d\n",&b);
	
	
}
