#include <stdio.h>
main()
{
int a=10;
loop:do
{
 if (a==15)
 {
  a=a+1;
  goto loop;
 }
 printf("\nvalue of a=%d",a);
 a++;
}
 while(a<20);
 }
