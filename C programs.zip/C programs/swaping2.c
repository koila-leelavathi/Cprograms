//swaping two numbers using temp variable in arthematic operations
#include<stdio.h>
main()
{
	int temp,a,b;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	b=b+a;
	a=b-a;
	b=b-a;
	printf("a=%d,b=%d",a,b);
}
