//post increment
#include<stdio.h>
main()
{
	int s,d;
	printf("enter the value of s:");
	scanf("%d",&s);
	d=s++;
	printf("d=%d",d);
}
