//Unary
#include<stdio.h>
main()
{
	int a,unary;
	printf("enter the values of a:");
	scanf("%d",&a);
	unary=-a;
	printf("unaru=%d",unary);
}
