//Write a program to print area of rectangle
#include<stdio.h>
main()
{
	int l,b,area;
	printf("enter the value of l,b:");
	scanf("%d%d",&l,&b);
	area=l*b;
	printf("area of rectangle=%d",area);
}
