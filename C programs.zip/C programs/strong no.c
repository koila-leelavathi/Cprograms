//145=1!+4!+5!
#include<stdio.h>
int main()
{
	int nu,su=0,fact=1,m=0,k,NUM;
	printf("enter a number to check whether the number is a Strong number or not>>");
	scanf("%d",&nu);
	NUM=nu;
	for(m;nu!=0;m++)
	{
		k=nu%10;
		nu=nu/10;
		for(k;k>0;k--)
		{
			fact=fact*k;		
		}
		su=su+fact;
		fact=1;
	}
	if (su==NUM)
	{
		printf("given number is a Strong number");
			
	}
	else
	{
		printf("given number is not a Strong number");
		}
}

