#include<stdio.h>
main()
{
   int a,b,c;
   printf("enter the value of a");
   scanf("%d",&a);
   b=--a;
   c=a--;
   printf("b=%d",b);
   printf("c=%d",c);
}
