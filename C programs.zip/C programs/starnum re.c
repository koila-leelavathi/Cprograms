#include <stdio.h>
void main()
{
	int a,i,j,n=10;
	for (i=n;i>=1;i--)
	{
		for (j=n;j>=1;j--){
			printf("%d",j);
		}
		
	    --n;	
		printf("\n");
		
	}
}
