////Write a program to print square
#include<stdio.h>
main()
{
	int n,result;
	int square(int);//function declaration
	printf("enter n value");
	scanf("%d",&n);
	result=square(n);//function call
	printf("result is=%d",result);
}
int square(int n)//function definition
{
return(n+2*n+2);
}
