#include <stdio.h>
void main()
{
	int number,sum=0,n,i;
	printf("enter the number=");
	scanf("%d",&number);
	for (i=0;number!=0;i++)
	{
		n=number%10;
		sum=(sum*10)+n;
		number=number/10;
	}
	printf("%d",sum);
}



