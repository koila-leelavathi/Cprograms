//Write a program to print one dimentional array
#include<stdio.h>
main()
{
	int a[10],n,i;
	printf("enter the value of n:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	 scanf("%d",&a[i]);	
	}
	for(i=0;i<n;i++)
	{
	 printf("%d",a[i]);
	 	
	}
}
