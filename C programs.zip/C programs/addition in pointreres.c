////Write a additon operator in pointers
#include<stdio.h>
main()
{
	int a=5,*pa,*pb,b=5,c,d;
	c=a+b;
	pa=&a;
	pb=&b;
	printf("&pa=%d\n",pa);
	printf("&pb=%d\n",pb);
	printf("a+b=%d\n",c);
	d=*pa+*pb;
	printf("*pa+*pb=%d\n",d);
	
}
