#include <stdio.h>
void main()
{
	int a,i,j,e[1000],o[1000],p[1000];
	printf("enter the range=");
	scanf("%d",&a);
	for (i=0;i<a;i++)
	{
		if (i%2==0)
		{
			e[i]=i;
		}
	}
	for (i=0;;i++)
	{
		printf("%3d",e[i]);
	}
}
