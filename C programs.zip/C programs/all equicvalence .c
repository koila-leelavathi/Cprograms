//All equivalce codition
#include<stdio.h>
main()
{
	int a,b,c,d;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c=(a==b);
	d=(a!=b);
	printf("c=%d,d=%d",c,d);
}
