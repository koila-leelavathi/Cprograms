// 371=3**3+7**3+1**3
#include<stdio.h>
int main()
{
	int nu,c(int);
	printf("enter a number to cheack whether the given no is  amstrong number or not>>");
	scanf("%d",&nu);
	c(nu);
}
int c(nu)
{
	int su,c=0,m,a,n=1,f;
	m=nu;a=m;
	for(n;m!=0;n++)
	{
		m=m/10;
		c=c+1;
	}
	for(n;a!=0;n++)
	{
		f=a%10;
		su=su+pow(f,c);
		a=a/10;
	}
	if(su==nu)
	{
		printf("given number is a amstrong number");
	}
	else
	{
		printf("given number is not amstrong number");
	}
}

