//Write a program for shift right and shift left using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	a>>=2;
	b<<=2;
	printf("a=%d",a);
	printf("b=%d",b);
}
