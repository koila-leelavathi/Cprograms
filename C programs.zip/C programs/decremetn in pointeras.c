#include<stdio.h>
main()
{
	int a=3,*p,d;
	p=&a;
	printf("%d\n",*p);
	printf("%d\n",p);
	d=--a;
	printf("%d\n",d);
	printf("%d\n",&d);
}
