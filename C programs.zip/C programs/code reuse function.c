//write a program to print code reuse
#include<stdio.h>
main()
{
	void y(),a(),b();
	y();
	a();
	b();
}
void y()
{
	printf("h");
	//a() it shows error why because u must menteion the proto type(void)
	//void a();it print the output a
	//a();nd give function call
}
void a()
{
	printf("i");
}
void b()
{
	y();
 a();
 
}
