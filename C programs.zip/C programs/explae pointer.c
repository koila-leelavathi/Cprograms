#include<stdio.h>
main()
{
	int x=7,*p;
	printf("%d\n",x);
	printf("%d\n",&x);
	p=&x;
	printf("%d\n",p);
	printf("%d\n",&p);
	float f=8.6;
	p=&f;
	printf("%f\n",p);
	printf("%f\n",&f);
}
