//swaping two numbers using temparay variable
#include<stdio.h>
main()
{
	int a,b,temp;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	temp=a;
	a=b;
	b=temp;
	printf("a=%d,b=%d",a,b);
}
