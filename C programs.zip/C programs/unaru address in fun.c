//Write a program to print unary address of the variable using functions
#include<stdio.h>
main()
{
	int a=2,c(int);
	c(a);
}
int c(a)
{
	int add;
	add=&a;
	printf("add=%d",add);
}
