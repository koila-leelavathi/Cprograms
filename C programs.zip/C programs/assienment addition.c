//assienment addition operator
#include<stdio.h>
main()
{
	int a,b;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	a+=b;
	printf("a=%d",a);
}
