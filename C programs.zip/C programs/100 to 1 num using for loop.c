//Write a program to print 100 to 1 using for loop
#include<stdio.h>
main()
{
	int i;
	printf("enter the value of i");
	scanf("%d",&i);
	for(i=100;i>=1;i--)
	{
	   printf("%d",i);	
	}
}
