//Write a program to print area of triangle
#include<stdio.h>
main()
{
	int area,b,h,a;
	printf("enter the value of b,h");
	scanf("%d%d",&b,&h);
	a=b*h;
	area=0.5*a;
	printf("area=%d",area);
}
