#include<stdio.h>
main()
{
	auto char a;
	int d=10;
	printf("%d\n%d",a,d);
}
