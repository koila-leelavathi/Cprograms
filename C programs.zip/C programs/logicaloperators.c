//logical operator
#include<stdio.h>
main()
{
	int a,b,c,d,e;
	printf("enter the value of a,b:\n");
	scanf("%d%d",&a,&b);
	c=(a>b)&&(a==b);
	printf("c=%d\n",c);
	d=(a==b)||(a<b);
	printf("d=%d\n",d);
	e=!(a<b);
	printf("e=%d\n",e);
}
