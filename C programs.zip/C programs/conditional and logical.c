//conditional and logical
#include<stdio.h>
main()
{
	int a,b,c,d;
	printf("enter the value of a:");
	scanf("%d%d",&a,&b);
	c=(a==b&&a>b?1:0);
	d=(a!=b||a<b?:0);
	printf("c=%d",c);
	printf("d=%d",d);
}
