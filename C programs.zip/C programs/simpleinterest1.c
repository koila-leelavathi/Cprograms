//Write a progam to print Simple Interest
#include<stdio.h>
main()
{
	int p,t,r,mul;
	float si;
	printf("enter the p,t,r value:");
	scanf("%d%d%d",&p,&t,&r);
	mul=p*t*r;
	si=mul/100;
	printf("simple interest=%f",si);
}
