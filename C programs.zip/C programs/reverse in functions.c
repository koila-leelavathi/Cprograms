#include <stdio.h>
main()
{
	int number,c(int);
	printf("enter the number=");
	scanf("%d",&number);
	c(number);
}
int c(number)
{
	int sum=0,n,i;
	for (i=0;number!=0;i++)
	{
		n=number%10;
		sum=(sum*10)+n;
		number=number/10;
	}
	printf("%d",sum);
}



