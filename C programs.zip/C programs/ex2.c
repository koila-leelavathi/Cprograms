#include<stdio.h>
int a=10;
main()
{
	int b=10,c;
	c=a+b;
	printf("%d",c);
}
