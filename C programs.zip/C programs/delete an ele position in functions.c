#include<stdio.h>
int main()
{
	int n,c(int);
	printf("enter the size of the array>>");
	scanf("%d",&n);
	c(n);
}
int c(n)
{
	int i,pos;
	int a[n];
	for(i=0;i<n;i++)
	{
		printf("enter the elements>>");
		scanf("%d",&a[i]);
	}
	printf("enter the position where the element have to be deleted>>");
	scanf("%d",&pos);
	for(i=pos;i<n-1;i++)
	{
		a[i]=a[i+1];
	}
	for(i=0;i<n-1;i++)
	{
		printf("%3d",a[i]);
	}
}
/*#include<stdio.h>
int main()
{
	int n,i,pos;
	printf("enter the size of the array>>");
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		printf("enter the %d element>>",i);
		scanf("%d",&a[i]);
		
	}
	printf("enter the position that have to be deleted>>");
	scanf("%d",&pos);
	for(i=0;i<n;i++){
		if( i==pos){
			continue;
		}
		else{
			printf("%3d",a[i]);
		}
		
	}
}*/
