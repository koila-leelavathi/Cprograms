//to display float value
#include<stdio.h>
float main()
{
	float a,b,c;
	a=12.3333;
	b=11.4545;
	c=a+b;
	printf("c=%f",c);
	return 0;
}
