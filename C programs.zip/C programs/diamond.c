#include <stdio.h>
int main()
{
	int r,c;
	for (r=1;r<=5;r++)
	{
		for (c=1;c<=5;c++)
		{
			if (((r==1)||(r==5))&&(c==3))
			{
				printf("*");
			}
			else
			{
				if (((r==2)||(r==4))&&((c==2)||(c==4)))
				{
					printf("*");
				}
				else
				{
					if ((r==3)&&((c==1)||(c==5)))
					{
						printf("*");
					}
				    else
				    {
				    printf(" ");
			     	}
			    printf("");
				}
			 printf(" ");
			}
		}printf("\n");
	}
}
