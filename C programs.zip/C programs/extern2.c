#include<stdio.h>
int c=10;
main()
{
	extern c;
	printf("%d",c);
}
