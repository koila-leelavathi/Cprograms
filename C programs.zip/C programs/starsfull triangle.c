//Half triangle
#include<stdio.h>
main()
{
	int i,j,n;
	for(i=0;i<n/2;i++)
	{
    for(j=1;j<=n;j++)
	{
	 if(j<=n/2-i/*j>n/n+i*/)
	 {
	  printf("*");	
	  }
	  else
	  printf(" ");
	  }
	 printf("\n");
	}
}
