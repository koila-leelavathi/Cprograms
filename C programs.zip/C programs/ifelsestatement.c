//write a program for given noumber is evenoumber using simple if condition
#include<stdio.h>
main()
{
	int a;
	printf("enter the value of a:\n");
	scanf("%d",&a);
	if(a%2==0);
	{
	printf("given noumber is even");
    }
}
