
#include<stdio.h>
main()
{
	int nu,rev,m=0,nu2;
	printf("Enter a number to check whether the given number is a palindrome number or not>>");
	scanf("%d",&nu);
	nu2=nu;
	for(m=0;nu!=0;m++)
	{
		rev=nu%10+rev*10;

           }
	printf("%d",rev);
	if(rev==nu2)  {
	printf("Given number is a palindrome number");
	}
	else {
		printf("Given number is not a palindrome number");
	}
	return 0;
}

