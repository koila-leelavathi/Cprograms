//wr
#include<stdio.h>
main()
{
	char str[]={'h','e','l','l','o','\0'};
	int i,c;
	c=0;
	for(i=0;str[i]!='\0';i++)
	{
	c++;
    }
	printf("%d",c);
}
