/*STRING REVERS*/
#include<stdio.h>
#include<string.h>
main()
{
	char x[100]="leela";
	printf("enter a string>>");
	gets(x);
	strrev(x);
	puts(x);
}
