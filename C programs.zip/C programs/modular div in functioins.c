//Write a program to print modular division of 2 numbers using functions
#include<stdio.h>
main()
{
	int a,b,z,modulardivision(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	z=modulardivision(a,b);
	printf("%d",z);
}
int modulardivision(a,b)
{
return (a%b);
}
