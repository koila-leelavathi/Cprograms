//Pre decrement
#include<stdio.h>
main()
{
	int a,b;
	printf("enter the value of a:");
	scanf("%d",&a);
	b=--a;
	printf("%d",b);
}
