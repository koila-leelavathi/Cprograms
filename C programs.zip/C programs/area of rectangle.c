//Write a program to print area of rectangle using functions
#include<stdio.h>
main()
{
	int l,b,d,area(int,int);
	printf("enter the value of l,b:");
	scanf("%d%d",&l,&b);
	d=area(l,b);
}
int area(l,b)
{
	int area;
	area=l*b;
	printf("%d",area);
	return area;
}
