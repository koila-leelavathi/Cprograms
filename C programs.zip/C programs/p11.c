//to display all arthematic operatation
#include<stdio.h>
int main()
{
	int a,b,c,d,e,f;
	a=10;
	b=30;
	c=a+b;
	d=a-b;
	e=a*b;
	f=a/b;
	printf("c=%d",c);
	printf("\nd=%d",d);
	printf("\ne=%d",e);
	printf("\nf=%d",f);
	return 0;
	
}
