//Write a program to print multiplicaion of two numbers using functions
#include<stdio.h>
main()
{
	int multiplication(int,int),a,b,z;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	z=multiplication(a,b);
	printf("%d",z);
}
int multiplication(a,b)
{
return (a*b);
}
