//Write a program for all bitwise operators using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	int d,e,f;
	d=(a|b);
	printf("d=%d",d);
	e=(a&b);
	printf("e=%d",e);
	f=(~a);
	printf("f=%d",f);
}

