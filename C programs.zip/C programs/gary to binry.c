#include<stdio.h>
#include<string.h>
main()
{
	int i,n,a[100],t;
	printf("enter the size of the array:");
	scanf("%d",&n);
	printf("enter the binary bits:");
	for(i=0;i<n;i++)
	{
	 scanf("%d",&a[i]);	
	}
	printf("%d",a[0]);
	t=a[0];
	for(i=1;i<n;i++)
	{
	 if(t+a[i]==2)
	 {
	  printf("0");
	  t=0;		
     }	
     else
     {
		t=t+a[i];
		printf("%d",t);	
		}
	}
}
