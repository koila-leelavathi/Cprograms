//mid 1 exlicit
#include<stdio.h>
main()
{
	int a,b;
	float f;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	f=(float)a/b;
	printf("%d",f);
}
