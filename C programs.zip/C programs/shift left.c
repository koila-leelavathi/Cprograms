#include<stdio.h>
main()
{
	int a,b,c,d,e,f;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	a<<=2;
	printf("%d",a);
}
