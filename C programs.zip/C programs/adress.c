/* adress of the elements in array*/
#include<stdio.h>
main()
{
	int a[5]={1,2,3,4,5};	
	printf("%d\n%d\n%d\n%d\n%d\n%d",sizeof(a[0]),sizeof(a[1]),a[2],&a[0],&a[1],&a[2]);
}
