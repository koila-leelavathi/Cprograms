//Write a program to print area of circle
#include<stdio.h>
main()
{
	int pi,r,area;
	printf("enter the value of r:");
	scanf("%d",&r);
	pi=3.14;
	area=pi*r*r;
	printf("%d",area);
}
