//to display area of circle
#include<stdio.h>
int main()
{ 
	int r,pi,area;
	r=12;
	pi=3.14;
	area=pi*r*r;
	printf("area=%d",area);
	return 0;
}
