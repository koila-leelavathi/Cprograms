//shift left and shift right
#include<stdio.h>
main()
{
	int a,b;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	a<<=2;
	b>>=2;
	printf("a=%d",a);
	printf("b=%d",b);
}
