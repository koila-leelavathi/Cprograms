//Duplicate elements
#include<stdio.h>
main()
{
	int a[20],i,j,k,n;
	printf("\nenter array size:");
	scanf("%d",&n);
	printf("\nenter the elements of an array:");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
    }
    printf("\n original array is:");
    for(i=0;i<n;i++)
    {
	 printf("%d\n",a[i]);	
	}
	printf("\n New array is:");
	for(i=0;i<n;i++)
	{
	 for(j=i+1;j<n;)
	 {
	  if(a[j]==a[i])
	  {
	    for(k=j;k<n;k++)
	      {
	       a[k]=a[k+1];		
	      }
	       n--;
		}		
	  
	  else
	  {
	    j++;		
	  }		
	 }	
	}
	for(i=0;i<n;i++)
	{
	  printf("%d\n",a[i]);	
	}
	
}
