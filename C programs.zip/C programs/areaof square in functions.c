//Write a program to print area of square
#include<stdio.h>
main()
{
	int area(int),a,c;
	printf("enter the value of a:");
	scanf("%d",&a);
	c=area(a);
}
int area(a)
{ 
  int area;
  area=(a*a);
  printf("%d",area);
  return area;
}
