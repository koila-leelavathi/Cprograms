#include<stdio.h>
void print()
{
	extern int a;
	a=30;
	printf("%d",c);
	
}
