//Write a program o printf function with arguments without return value
#include<stdio.h>
main()
{
	int add(int,int);
	int x=10,y=11;
	add(x,y);
}
int add(int a,int b)
{
	int result;
	result=a+b;
	printf("%d",result);
}

