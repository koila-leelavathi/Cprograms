#include <stdio.h>
void main()
{
	int i;
    for (i=65;i<=97;i++)
    printf("%d==%c\n",i,i);
}
