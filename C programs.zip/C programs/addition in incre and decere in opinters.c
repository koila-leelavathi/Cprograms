//Writet a program for addition in incerement in pointers
#include<stdio.h>
main()
{
	int a=10,*pa,*pb,b=10,c,d;
	pa=&a;
	pb=&b;
	printf("%d\n",pa);
	pritnf("%d\n",&a);
	pritnf("%d\n",pb);
	pritnf("%d\n",&b);
	pa++;
	printf("%d\n",pa);
	pb--;
	printf("%d\n",pb);
	
}
