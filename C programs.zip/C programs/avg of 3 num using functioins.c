//Write a program to print average of three numbers using functions
#include<stdio.h>
main()
{
	int a,b,c,avg(int,int,int),d;
	printf("enter the value of a,b,c:");
	scanf("%d%d%d",&a,&b,&c);
	avg(a,b,c);
}
int avg(a,b,c)
{
	int sum,e;
	sum=(a+b+c);
	e=sum/3;
	printf("%d",e);
}
