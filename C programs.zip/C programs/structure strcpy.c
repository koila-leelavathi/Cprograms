#include<stdio.h>
main()
{
	struct disk
	{
	 char co[15];
	 float type;
	 int price;	
	};
	struct disk d1={"copy",1.44,20};
	struct d3;
	
	strcpy(d2.co,d1.co);
	d2.type=d1.type;
	d3.price=d1.peice;
	d3=d2;
	printf("%s %g %d",d1.type);
	
}
