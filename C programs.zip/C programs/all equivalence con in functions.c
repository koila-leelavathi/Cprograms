//Write a program for all equivalence conditions using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	int d,e;
	d=(a==b);
	e=(a!=b);
	printf("d=%d,e=%d",d,e);
}
