#include <stdio.h>
void main()
{
	int cp,sp,profit,loss;
	float p,l;
	printf("enter the total cost price cp=");
	scanf("%d",&cp);
	printf("enter the selling price sp=");
	scanf("%d",&sp);
	if (sp<cp)
	{
		loss=cp-sp;
		l=(loss*100)/cp;
		printf("Loss is=%d and profit is= 0\n",loss);
		printf("your loss percentage is=%f%%",l);
	}
    if (sp>cp)
	{
		profit=sp-cp;
		p=(profit*100)/cp;
		printf("Profit is=%d and loss is= 0\n",profit);
		printf("your profit percentage is=%f%%",p);
	}
	if (sp==cp)
     {
		printf("profit is 0 and loss is 0");
	}		
}
