//mid 1 ist c
#include<stdio.h>
main()
{
	int a=0,x=1.2,c=1,y=2.5,d;
	d=((x>y)+!a||c++);
	printf("%d",d);
}
