//Write a program to print size 
#include<stdio.h>
main()
{
	int a;
	float b;
	char c;
	printf("a=%d",sizeof(a));
	printf("b=%d",sizeof(b));
	printf("c=%d",sizeof(c));
}
