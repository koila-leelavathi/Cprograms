//string copy
#include<stdio.h>
main()
{
	char str1[6]={'h','e','l','l','o','\0'},str2[3];
	int i,j;
	for(i=0;str1[i]!='\0';i++)
	{
	}
    for(j=0;j<i;j++)
    {
	  str2[j]=str1[j];	
	}
     printf("%s",str2);

}
