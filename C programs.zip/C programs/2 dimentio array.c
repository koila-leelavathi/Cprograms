//Write a program to print two dimentional array
#include<stdio.h>
main()
{
	int a[10][10],n,l,i,j;
	printf("enter the value of n,l:");
	scanf("%d%d",&n,&l);
	for(i=0;i<n;i++)
	{
	 for(j=0;j<l;j++)
	 {
	   scanf("%d%d",&a[i][j]);		
	 }	
	}
	for(i=0;i<n;i++)
	{
	 for(j=0;j<l;j++)
	 {
	  printf("%d%d",a[i][j]);
	 }	
	}
} 
