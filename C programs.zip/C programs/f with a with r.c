//Write a program o printf function with arguments with return value
#include<stdio.h>
main()
{
	int add(int,int),z;
	int x=10,y=11;
	z=add(x,y);
	printf("z=%d",z);
}
int add(int a,int b)
{
	int result;
	result=a+b;
	printf("result=%d",result);
	result++;
	return(result);
}

