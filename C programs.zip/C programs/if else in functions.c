#include <stdio.h>
main()
{
	int a,c(int);
	printf("enter the value of a=");
	scanf("%d",&a);
	c(a);
}
int c(int a)
{
	if (a%2==0)
	{
     printf("Entered no is divisible by 2");
    }
    else
    printf("Entered no is not divisible by 2");
}
