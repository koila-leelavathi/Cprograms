#include<stdio.h>
//#include<string.h>
main()
{
	/*int p;/**q,*w,*r,n,
	char *a[0];
	a[0]="leeela";
	/*p=&a[0];
	q=&a[1];
	w=&a[2];
	r=&a[3];
	printf("a[0]=%d\n",*p);
	printf("a[1]=%d\n",*q);
	printf("a[2]=%d\n",*w);
	printf("a[3]=%d\n",*r);
	printf("%s",a[0])*/
	struct book
	{
	 int pages;
	 char author[90];
	 float price;	
	};
	struct book b={20,"leela",88.8};
	printf("pges=%d",b.pages);
	printf("author=%s",b.author);
	printf("price=%f",b.price);
}
