//Stars in reverse
#include<stdio.h>
main()
{
	int a,b;
	for(a=0;a<=5;a++)
	{
	  for(b=a;b<=5;b++)	
	{
	printf("*");
    }
    printf("\n");
    }
}
