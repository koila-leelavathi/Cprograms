//Write a program for conditional and logical operator using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	int d,e;
	d=(a>b&&a==b?1:0);
    e=(a<b||a!=b?1:0);	
    printf("d=%d,e=%d",d,e);
}
