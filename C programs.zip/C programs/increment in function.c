//write a program to print increment value in multiple times using functions
#include<stdio.h>
main()
{
	void a(),b();
	a();
	b();
}
void a()
{
	int z=3;
	z++;
	printf("%d",z);
}
void b()
{
	a();
}

