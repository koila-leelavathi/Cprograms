#include <stdio.h> 
  
int main () 
{ 
 
   for( ; ; ) 
   { 
      printf("This loop will run forever.\n"); 
   } 
 
   return 0; 
} 
