//Write a program o printf function without arguments without return value
#include<stdio.h>
main()
{
	int add();
	add();
}
int add()
{
	int add,x=10,y=11;
	add=x+y;
	printf("add=%d",add);
}

