//Write a program to print coma operator using functions

