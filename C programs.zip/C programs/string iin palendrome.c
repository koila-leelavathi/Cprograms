#include<stdio.h>
main()
{
	char *a;
	int i,len,flag=0;
	printf("\nenter a string:");
	scanf("%d",&a);
	len=strlen(a);
	for(i=0;i<len;i++)
	{
	  if(a[i]==a[len-i-1])
	  flag=flag+1;	
	}
	if(flag==len)
	printf("\nthe string is palindrome");
	else
	printf("\nstring is not a palindrome");
}
