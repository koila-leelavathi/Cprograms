//Write a program for post decrement using functions
#include<stdio.h>
main()
{
	int a,c(int);
	printf("enter the value of a:");
	scanf("%d",&a);
	c(a);
}
int c(a)
{
	int b;
	b=a--;
	printf("b=%d",b);
}
