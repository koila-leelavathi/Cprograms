#include<stdio.h>
main()
{
	int a,b,e;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	e=(~a);
	printf("e=%d",e);
}
