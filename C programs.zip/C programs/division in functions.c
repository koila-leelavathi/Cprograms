//Write a program to print divisioin of 2 num using functions
#include<stdio.h>
main()
{
	int divisioin(int,int),a,b,z;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	z=division(a,b);
	printf("%d",z);
}
int division(a,b)
{
return(a/b);
}
