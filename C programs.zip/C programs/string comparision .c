/*STRING COMPARISON*/
#include<stdio.h>
#include<string.h>
main( )
{
	int n;
	char x[50]="leela",y[50]="vathi";
	n=strcmp(y,x);
	printf("%d",n);
	
}
