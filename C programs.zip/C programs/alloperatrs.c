//All arthematic operation
#include<stdio.h>
main()
{
	int a,b,c,d,e,f,g;
	printf("ener the value of a,b:");
	scanf("%d%d",&a,&b);
	c=a+b;
	d=a-b;
	e=a*b;
	f=a/b;
	g=a%b;
	printf("c=%d,d=%d,e=%d,f=%d,g=%d",c,d,e,f,g);
}
