#include<stdio.h>
main()
{
struct book1
{
	int pages;
	char book[20];
	float price;
};
struct book1 b1;
struct book1 b2;
struct book1 b3;
printf("\n size of pages=%d",sizeof(b1.pages));
printf("\n size of book=%d",sizeof(b2.book));
printf("\n size of pages=%d",sizeof(b3.price));
printf("\n size of b1=%d",sizeof(b1));
printf("\n size of b2=%d",sizeof(b2));
/*printf("\n size of book=%c",sizeof(b2.book));
printf("\n size of pages=%f",sizeof(b3.price));*/
}
