//Write a program to print 1 to 100 numbers and its square values using for loop
#include<stdio.h>
main()
{
	int i;
	printf("enter the value of i:");
	scanf("%d",&i);
	for(i=1;i<=100;i++)
	{
	  printf("i=%d,square=%d\n",i,i*i);
	}
}
