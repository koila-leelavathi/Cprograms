//all assienment operators
#include<stdio.h>
main()
{
	int a,b;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	a+=b;
	printf("sum=%d\n",a);
	a-=b;
	printf("subtraction=%d\n",a);
	a*=b;
	printf("multiplication=%d\n",a);
	a/=b;
	printf("division=%d\n",a);
	a%=b;
	printf("modular division=%d\n",a);
} 
