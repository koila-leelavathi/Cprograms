//leep year
#include<stdio.h>
main()
{
	int year,c(int);
	printf("enter the value of year:");
	scanf("%d",&year);
	c(year);
}
int c(year)
{
	if((year%4==0)&&(year%100!=0)||(year%400==0))
	
			{
			    printf("%d is the year is leep year:",year);	
				}
			else
			{
				printf("%d not a leep year",year);
				}
	
}
