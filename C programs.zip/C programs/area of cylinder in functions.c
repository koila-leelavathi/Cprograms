//Write a program for area of cylinder
#include<stdio.h>
main()
{
	int pi,r,h,area(int,int);
	printf("enter the value of r,h:");
	scanf("%d%d",&r,&h);
	area(r,h);
}
int area(r,h)
{
	int area,c,pi;
	pi=3.14;
	c=r*h*2;
	area=pi*c;
	printf("%d",area);
	
}
