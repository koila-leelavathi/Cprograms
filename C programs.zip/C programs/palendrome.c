//palendrome number
#include<stdio.h>
main()
{
	int n,sum=0,v,x;
	printf("enter the value of n:");
	scanf("%d",&n);
	x=n;
	while(n!=0)
	{
	 v=n%10;
	 sum=sum*10+v;
	 n=n/10;		
	}
    printf("%d",sum);
    if(x==sum)
    {
	 printf("this is palendrome");
	}   
    else
    {
		printf("Not a palendrome");
	}
}
