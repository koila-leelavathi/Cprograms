#include<stdio.h>
main()
{
  int n,c(int);
  printf("enter the size of the array:");
  scanf("%d",&n);
  c(n);
}
int c(n)
{
   int i,e,position,a[100];
  printf("enter the elements:");
  for(i=0;i<n;i++)
  {
  scanf("%d",&a[i]);
  }
  printf("enter the positon");
  scanf("%d",&position);
  printf("enter the insert element:");
  scanf("%d",&e);
  for(i=n-1;i>=position;i--)
  {
   a[i+1]=a[i];
  }
  a[position]=e;
  printf("the final element:");
  for(i=0;i<n+1;i++)
  {
  printf("%d",a[i]);
  }

}
