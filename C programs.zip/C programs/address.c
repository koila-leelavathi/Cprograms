//Address of a number
#include<stdio.h>
main()
{
	int a,address;
	a=2;
	address=&a;
	printf("address=%d",address);
}
