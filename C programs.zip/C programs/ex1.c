#include<stdio.h>
#include<string.h>
main()
{
	char a[9]="leela",b[9]="vathi";
	int len;
	len=strcat(a,b);
	printf("%s",len);
}
