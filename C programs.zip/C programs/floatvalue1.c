//Float values 
#include<stdio.h>
main()
{
	float x=9;
	printf("%f",x);
}
