//not equal to 
#include<stdio.h>
main()
{
	int a,b,c;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c=(a!=b);
	printf("c=%d",c);
}
