#include<stdio.h>
main()
{
	char *name[]={"rgukt"};
	printf("%c",*name);
}
