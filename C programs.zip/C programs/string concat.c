//write a program to print concate(add)string
#include<stdio.h>
main()
{
	char str[]
}
