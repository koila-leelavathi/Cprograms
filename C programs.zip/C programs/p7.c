//to display circumference of circle
#include<stdio.h>
int main()
{
	int r,pi,area;
	r=10;
	pi=3.14;
	area=2*pi*r*r;
	printf("area=%d",area);
	return 0;
}
