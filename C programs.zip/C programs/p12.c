//to display area of triangle
#include<stdio.h>
int main()
{
	int b,h,area;
	b=20;
	h=40;
	area=0.5*b*h;
	printf("area=%d",area);
	return 0;
	
}
