//to calculate simple interest
#include<stdio.h>
int main()
{
	int p,t,r,si;
	p=10;
	t=20;
	r=30;
	si=p*t*r/100;
	printf("si=%d",si);
	return 0;
}
