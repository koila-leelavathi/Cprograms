#include<stdio.h>
include "variable.c"
int c=0;
void print();
#include "3.c"
int main()
{
	c=10;
	printf("%d",c);
	printf();
	printf("%d",c);
	display();
	printf("%d",c);
}
