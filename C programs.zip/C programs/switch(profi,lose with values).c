//Write a program to print profit and lose with the value
#include<Stdio.h>
main()
{
	int costprise,sellingprise,profit,lose,c,totalvalue;
	printf("enter the value of cost prise:");
	scanf("%d",&costprise);
	printf("enter the value of selling prise:");
	scanf("%d",&sellingprise);
	lose=sellingprise-costprise;
	profit=costprise-sellingprise;
	totalvalue=(sellingprise/costprise)*100;
	printf("%d",totalvalue);
	printf("choose option to perform:\n 1.profit\n2.lose");
	printf("\nchoose your option");
	scanf("%d",&c);
	switch(c)
	{
	case 1:
	printf("\n ");
	break;
	default:
	printf("\nThere is no lose and profit");
	break;
	}
}
