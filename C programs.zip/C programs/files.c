#include<stdio.h>
main()
{
	
}
