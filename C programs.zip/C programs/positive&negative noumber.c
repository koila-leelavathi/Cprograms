//Write a program to print positive and negative noumber
#include<stdio.h>
main()
{
	int a;
	printf("enter the value of a:");
	scanf("%d",&a);
	if(a>0)
	{
	   printf("The given noumber is positive noumber",a);
	}
	if(a<0)
    {
	  printf("The given noumber is negative noumber:",a);	
	}
}
