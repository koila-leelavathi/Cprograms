//Write a program to print subtract numbers using 2 loop using for loop
#include<stdio.h>
main()
{
	int i,j,sub;
	printf("enter the value of i,j:");
	scanf("%d%d",&i,&j);
	for(i=3;i>=1;i--)
	{
	for(j=1;j<=2;j++)
	{
	   sub=i-j;
	   printf("i=%dj=%dsub=%d",i,j,sub);	
    }	
	}
}
