//Write a program for all increments and decrements using functions
#include<stdio.h>
main()
{
	int a,b,c(int,int);
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c(a,b);
}
int c(a,b)
{
	int d,e,f,g;
	d=++a;
	printf("d=%d",d);
	e=a++;
	printf("e=%d",e);
	f=--b;
	printf("f=%d",f);
	g=b--;
	printf("g=%d",g);
}
