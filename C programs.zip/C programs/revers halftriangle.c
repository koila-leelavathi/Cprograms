//Write a program to print revers half triangle
#include<stdio.h>
main()
{
	int i,j;
	for(i=1;i<11;i++)
	{
	  for(j=i;j<=11;j++)	
	{
	 printf("1");
    }
       printf("\n");
	}
}
