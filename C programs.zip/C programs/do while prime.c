#include <stdio.h>
int main()
{
	int k=2,m,c;
	printf("enter the no to be checked whether prime or not=");
	scanf("%d",&m);
	do
	{
		if (m%k==0)
		c=c+1;
		k++;
	}
	while (k<=m);
	if (c==2)
	{
		printf("%d is a prime number",m);
	}
	else
	{
		printf("%d is not a prime number",m);
	}
}
