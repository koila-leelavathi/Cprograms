#include<stdio.h>
main()
{
	int a,b,c,d,e,f;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c=a&b;
	printf("c=%d",c);
}
