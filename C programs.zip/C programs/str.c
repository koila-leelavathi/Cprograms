#include <stdio.h>
#include <conio.h>
void main()
{
	char str1[10]="hel" ,str2[4]="llo";
	int i,j,k,c=0;
	for (i=0;str1[i]!='\o';i++)
	{
		c++;
	}
	printf("%d",c);
}
