//Bitwise operation
#include<stdio.h>
main()
{
	int a,b,c,d,e,f;
	printf("enter the value of a,b:");
	scanf("%d%d",&a,&b);
	c=(a&b);
	printf("c=%d",c);
	d=(a|b);
	printf("d=%d",d);
	e=(~a);
	printf("e=%d",e);
	f=(a^b);
	printf("f=%d",f);
}
