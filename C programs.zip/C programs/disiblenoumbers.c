//Write a program to print divisible noumbers
#include<stdio.h>
main()
{
	int a;
	printf("enter the value of a:");
	scanf("%d",&a);
	if(a%5==0)
	{
	   printf("%d is divisible by 5");
	}
	else
	if(a%7==0)
	{
	   printf("%d is disible by 7");	
	}
	else 
	if(a%2==0)
	{
	   printf("%d is divisible by 2");	
	}
	else
	{
	   printf("%d is not divisible by 5,7,2");	
	}
}
