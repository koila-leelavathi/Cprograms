#include<stdio.h>
main()
{
	extern int a=9;
	extern int b=1;
	
}
