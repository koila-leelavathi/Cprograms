//Triangle
#include<stdio.h>
main()
{
	char i,j,c(int,int);
	printf("enter the value of i,j:");
	scanf("%d%d",&i,&j);
	c(i,j);
}
char c(i,j)
{
	for (i;i<='E';i++)
	{
	 for(j='A';j<=i;j++)	
	{
	 printf("%c",i);
	}
	printf("\n");
    }
}
