//palendrome number in functions
#include<stdio.h>
main()
{
	int n,fun(int);
	printf("enter the value of n:");
	scanf("%d",&n);
	fun(n);
}
int fun(int n)
{
	int sum=0,v,x;
	x=n;
	while(n!=0)
	{
	 v=n%10;
	 sum=sum*10+v;
	 n=n/10;		
	}
    printf("%d",sum);
    if(x==sum)
    {
	 printf("this is palendrome");
	}   
    else
    {
		printf("Not a palendrome");
	}
}
