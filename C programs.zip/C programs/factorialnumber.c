//Write a program to print factorial noumber
#include<stdio.h>
main()
{
	int fact,n,i;
	printf("enter the value of n:\n");
	scanf("%d",&n);
	fact=1;
	for(i=1;i<=n;i++)
	 {
	  fact=fact*i;
      }
       printf("factorial noumber is%d",fact);
}

