//Write a program to print revers string
#include<stdio.h>
main()
{
	char str[6]={'h','e','l','l','o','\0'},temp;
	int i,n=0;
	for(i=0;str[i]!=0;i++)
	{
		n++;
    }
	for(i=0;i<n/2;i++)
	{
	   temp=str[n-i-1];
	   str[n-i-1]=str[i];
	   str[i]=temp;
    } 
    printf("%d",str[n]);
}
